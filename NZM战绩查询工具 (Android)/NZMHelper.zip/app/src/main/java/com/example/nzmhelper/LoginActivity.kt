package com.example.nzmhelper

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.nzmhelper.databinding.ActivityLoginBinding
import kotlinx.coroutines.*

class LoginActivity : AppCompatActivity() {
    companion object { val apiService = ApiService() }

    private lateinit var binding: ActivityLoginBinding
    private var isQQ = true
    private var pollingJob: Job? = null
    private var wxUuid: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tabQQ.setOnClickListener { switchType(true) }
        binding.tabWeChat.setOnClickListener { switchType(false) }
        binding.btnRefresh.setOnClickListener { refreshQr() }

        refreshQr()
    }

    private fun switchType(qq: Boolean) {
        isQQ = qq
        binding.tabQQ.setTextColor(ContextCompat.getColor(this, if (qq) R.color.accent else R.color.text_sub))
        binding.tabWeChat.setTextColor(ContextCompat.getColor(this, if (!qq) R.color.accent else R.color.text_sub))
        refreshQr()
    }

    private fun refreshQr() {
        pollingJob?.cancel()
        binding.tvStatus.text = "正在获取二维码..."
        binding.imgQr.setImageBitmap(null)

        lifecycleScope.launch {
            if (isQQ) {
                val bytes = apiService.getQqQrCode()
                if (bytes != null) {
                    binding.imgQr.setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.size))
                    binding.tvStatus.text = "请使用 QQ 扫码"
                    startPoll()
                } else {
                    binding.tvStatus.text = "获取失败，请重试"
                }
            } else {
                val (bytes, uuid) = apiService.getWxQrCode()
                if (bytes != null && uuid != null) {
                    binding.imgQr.setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.size))
                    wxUuid = uuid
                    binding.tvStatus.text = "请使用微信扫码"
                    startPoll()
                } else {
                    binding.tvStatus.text = "获取失败，请重试"
                }
            }
        }
    }

    private fun startPoll() {
        pollingJob = lifecycleScope.launch {
            while (isActive) {
                val status = if (isQQ) apiService.checkQqQr() else apiService.checkWxQr(wxUuid ?: "")
                if (status == 0) {
                    Toast.makeText(this@LoginActivity, "登录成功", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                    finish()
                    break
                }
                delay(3000)
            }
        }
    }
}